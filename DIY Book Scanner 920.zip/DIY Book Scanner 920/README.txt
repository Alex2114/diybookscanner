These files are meant to be cut on 9x48" sheets of 3/4" (18mm) baltic birch plywood.

Although the layout differs from the cut guides (sheet A .9.9 image.png, sheet B .9.9 image.png) the depts are the same. 



For support:
============

Ask on the forums at http://diybookscanner.org/forum
